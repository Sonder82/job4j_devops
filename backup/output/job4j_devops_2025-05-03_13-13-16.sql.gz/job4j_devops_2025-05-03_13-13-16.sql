--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3
-- Dumped by pg_dump version 14.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calc_event_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.calc_event_type AS ENUM (
    'ADDITIONAL',
    'SUBTRACTION',
    'MULTIPLICATION',
    'DIVISION'
);


ALTER TYPE public.calc_event_type OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: calc_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calc_event (
    id integer NOT NULL,
    user_id integer,
    first double precision NOT NULL,
    second double precision NOT NULL,
    result double precision NOT NULL,
    create_date timestamp without time zone DEFAULT now(),
    calc_event_type character varying(20) NOT NULL
);


ALTER TABLE public.calc_event OWNER TO postgres;

--
-- Name: calc_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calc_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.calc_event_id_seq OWNER TO postgres;

--
-- Name: calc_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calc_event_id_seq OWNED BY public.calc_event.id;


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.results (
    id integer NOT NULL,
    first double precision NOT NULL,
    second double precision NOT NULL,
    result double precision NOT NULL,
    create_date timestamp without time zone DEFAULT now(),
    calc_event_type character varying(20) NOT NULL
);


ALTER TABLE public.results OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.results_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.results_id_seq OWNER TO postgres;

--
-- Name: results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.results_id_seq OWNED BY public.results.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(2000),
    first_arg bigint,
    second_arg bigint,
    result bigint,
    create_date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: calc_event id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calc_event ALTER COLUMN id SET DEFAULT nextval('public.calc_event_id_seq'::regclass);


--
-- Name: results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results ALTER COLUMN id SET DEFAULT nextval('public.results_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: calc_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calc_event (id, user_id, first, second, result, create_date, calc_event_type) FROM stdin;
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
create_users_table	novoselov	db/changelog/changeset/001_ddl_create_tables.sql	2025-04-03 13:22:30.880654	1	EXECUTED	9:768d088239f67e217a96fc085b75d811	sql		\N	4.30.0	\N	\N	3668550607
alter_table_users_add_columns	anovoselov	db/changelog/changeset/002_ddl_alter_table_users_add_columns.sql	2025-04-03 13:22:30.954828	2	EXECUTED	9:0eca7cb2a84d6391a5006664f0f87e9a	sql		\N	4.30.0	\N	\N	3668550607
add_user_create_date	anovoselov	db/changelog/changeset/003_ddl_alter_add_user_create_date.sql	2025-04-03 13:22:31.01676	3	EXECUTED	9:2290b7326b89c03b45e590bdcd66d2bb	sql		\N	4.30.0	\N	\N	3668550607
create_calc_event_table	novoselov	db/changelog/changeset/004_ddl_create_calc_event_table.sql	2025-04-03 13:22:31.103985	4	EXECUTED	9:efa74eb768000915289f1b91afe08ce5	sql		\N	4.30.0	\N	\N	3668550607
create_result_table	novoselov	db/changelog/changeset/005_ddl_create_result_table.sql	2025-04-03 13:22:31.174053	5	EXECUTED	9:5418ab17ec1823701c376f079222348d	sql		\N	4.30.0	\N	\N	3668550607
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.results (id, first, second, result, create_date, calc_event_type) FROM stdin;
1	1	1	2	\N	0
2	1	1	2	\N	0
3	1	1	2	\N	0
4	1	1	2	\N	0
5	5	7	12	\N	0
6	5	7	12	\N	0
7	5	7	12	\N	0
8	5	7	12	\N	0
9	5	7	12	\N	0
10	5	7	12	\N	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, first_arg, second_arg, result, create_date) FROM stdin;
\.


--
-- Name: calc_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calc_event_id_seq', 1, false);


--
-- Name: results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.results_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: calc_event calc_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calc_event
    ADD CONSTRAINT calc_event_pkey PRIMARY KEY (id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: calc_event calc_event_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calc_event
    ADD CONSTRAINT calc_event_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

